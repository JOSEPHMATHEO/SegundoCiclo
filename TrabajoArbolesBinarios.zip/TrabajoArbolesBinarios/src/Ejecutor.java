import paquete2.*;

public class Ejecutor {
    
    public static void main(String[] args) {
        
        aBB arbolito = new aBB();
        
        arbolito.add(10);
        arbolito.add(5);
        arbolito.add(2);
        arbolito.add(8);
        arbolito.add(11);
        arbolito.add(14);
        arbolito.add(21);
        
        System.out.println("Arbol Binario de Busqueda 1 \n");
        
        System.out.println("---InOrden---");
        arbolito.inOrden(arbolito.root);
        
        System.out.println("\n\n---PreOrden---");
        arbolito.preOrden(arbolito.root);
        
        System.out.println("\n\n---PostOrden---");
        arbolito.posOrden(arbolito.root);
        System.out.println("");
        
        arbolito.delete(5);
        arbolito.delete(10);
        arbolito.delete(2);
        
        System.out.println("\nArbol Binario de Busqueda 2");
        System.out.println("\nArbol sin el nodo 5, 10, 2");
        
        System.out.println("\n---InOrden---");
        arbolito.inOrden(arbolito.root);
        
        System.out.println("\n\n---PreOrden---");
        arbolito.preOrden(arbolito.root);
        
        System.out.println("\n\n---PostOrden---");
        arbolito.posOrden(arbolito.root);
        System.out.println("");
        
    }
    
}
