package paquete2;

public class Node {
    
    int value;
    Node left;
    Node right;
    
    public Node(int valor){
        
        value = valor;
        right = null;
        left = null;
    
    }
    
}
